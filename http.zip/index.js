const http = require('http')
const port = 1308

const handleRequest = (req , res) =>{
    res.write("<h1>Name : Harshal Narigara</h1>")
    res.write("<h1>E-mail : harshalnarigara1308@gmail.com</h1>")
    res.write("<h1>Age : 19</h1>")
    res.end()
}

const server = http.createServer(handleRequest)

server.listen(port , (err) => {
    if(err){
        console.log("Server is not responding")
    }else{
        console.log("Server started at : " + port)
    }
})